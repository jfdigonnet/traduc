/*
 * Cerberus  Copyright (C) 2013  vertigo17
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This file is part of Cerberus.
 *
 * Cerberus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cerberus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cerberus.  If not, see <http://www.gnu.org/licenses/>.
 */
package org.cerberus.serviceEngine.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;

import org.apache.log4j.Level;
import org.cerberus.entity.CountryEnvParam;
import org.cerberus.entity.MessageGeneral;
import org.cerberus.entity.MessageGeneralEnum;
import org.cerberus.entity.TestCaseExecution;
import org.cerberus.entity.TCase;
import org.cerberus.exception.CerberusException;
import org.cerberus.log.MyLogger;
import org.cerberus.service.IApplicationService;
import org.cerberus.service.ITestCaseCountryService;
import org.cerberus.serviceEngine.IExecutionCheckService;
import org.cerberus.util.ParameterParserUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * {Insert class description here}
 *
 * @author Tiago Bernardes
 * @version 1.0, 15/01/2013
 * @since 0.9.0
 */
@Service
public class ExecutionCheckService implements IExecutionCheckService {

    // private TestCaseExecution execution;
    // private Environment environment;
    @Autowired
    private IApplicationService applicationService;
    @Autowired
    private ITestCaseCountryService testCaseCountryService;
    private MessageGeneral message;

    @Override
    public MessageGeneral checkTestCaseExecution(TestCaseExecution tCExecution) {
        if (tCExecution.isManualURL()) {
            /**
             * Manual application connectivity parameter
             */
            if (this.checkTestCaseActive(tCExecution.gettCase())
                    && this.checkTestCaseNotManual(tCExecution.gettCase())
                    && this.checkTypeEnvironment(tCExecution)
                    && this.checkCountry(tCExecution)
                    && this.checkMaintenanceTime(tCExecution)) {
                return new MessageGeneral(MessageGeneralEnum.EXECUTION_PE_CHECKINGPARAMETERS);
            }
        } else {
            /**
             * Automatic application connectivity parameter (from database)
             */
            if (this.checkEnvironmentActive(tCExecution.getCountryEnvParam())
                    && this.checkTestCaseNotManual(tCExecution.gettCase())
                    && this.checkRangeBuildRevision(tCExecution)
                    && this.checkTargetBuildRevision(tCExecution)
                    && this.checkActiveEnvironmentGroup(tCExecution)
                    && this.checkTestCaseActive(tCExecution.gettCase())
                    && this.checkTypeEnvironment(tCExecution)
                    && this.checkCountry(tCExecution)
                    && this.checkMaintenanceTime(tCExecution)
                    && this.checkVerboseIsNotZeroForFirefoxOnly(tCExecution)) {
                return new MessageGeneral(MessageGeneralEnum.EXECUTION_PE_CHECKINGPARAMETERS);
            }
        }
        return message;
    }

    private boolean checkEnvironmentActive(CountryEnvParam cep) {
        MyLogger.log(ExecutionCheckService.class.getName(), Level.DEBUG, "Checking if environment is active");
        if (cep.isActive()) {
            return true;
        }
        message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_ENVIRONMENT_NOTACTIVE);
        return false;
    }

    private boolean checkTestCaseActive(TCase testCase) {
        MyLogger.log(ExecutionCheckService.class.getName(), Level.DEBUG, "Checking if testcase is active");
        if (testCase.getActive().equals("Y")) {
            return true;
        }
        message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_TESTCASE_NOTACTIVE);
        return false;
    }

    private boolean checkTestCaseNotManual(TCase testCase) {
        MyLogger.log(ExecutionCheckService.class.getName(), Level.DEBUG, "Checking if testcase is not MANUAL");
        if (!(testCase.getGroup().equals("MANUAL"))) {
            return true;
        }
        message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_TESTCASE_ISMANUAL);
        return false;
    }

    private boolean checkTypeEnvironment(TestCaseExecution tCExecution) {
        MyLogger.log(ExecutionCheckService.class.getName(), Level.DEBUG, "Checking if application environment type is compatible with environment type");
        try {
            if (applicationService.findApplicationByKey(tCExecution.gettCase().getApplication()).getType().equalsIgnoreCase("COMPARISON")) {
                if (tCExecution.gettCase().getGroup().equalsIgnoreCase("COMPARATIVE")) {
                    message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_TYPE_DIFFERENT);
                    return false;
                }
            }
        } catch (CerberusException ex) {
            Logger.getLogger(ExecutionCheckService.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        return true;
    }

    private boolean checkRangeBuildRevision(TestCaseExecution tCExecution) {
        MyLogger.log(ExecutionCheckService.class.getName(), Level.DEBUG, "Checking if test can be executed in this build and revision");
        TCase tc = tCExecution.gettCase();
        CountryEnvParam env = tCExecution.getCountryEnvParam();
        String tcFromSprint = ParameterParserUtil.parseStringParam(tc.getFromSprint(), "");
        String tcToSprint = ParameterParserUtil.parseStringParam(tc.getToSprint(), "");
        String tcFromRevision = ParameterParserUtil.parseStringParam(tc.getFromRevision(), "");
        String tcToRevision = ParameterParserUtil.parseStringParam(tc.getToRevision(), "");
        String sprint = ParameterParserUtil.parseStringParam(env.getBuild(), "");
        String revision = ParameterParserUtil.parseStringParam(env.getRevision(), "");

        if (!tcFromSprint.isEmpty() && sprint != null) {
            try {
                int dif = this.compareBuild(sprint, tcFromSprint);
                if (dif == 0) {
                    if (!tcFromRevision.isEmpty() && revision != null) {
                        if (this.compareRevision(revision, tcFromRevision) < 0) {
                            message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_RANGE_DIFFERENT);
                            return false;
                        }
                    }
                } else if (dif < 0) {
                    message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_RANGE_DIFFERENT);
                    return false;
                }
            } catch (NumberFormatException exception) {
                message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_RANGE_WRONGFORMAT);
                return false;
            }
        }

        if (!tcToSprint.isEmpty() && sprint != null) {
            try {
                int dif = this.compareBuild(tcToSprint, sprint);
                if (dif == 0) {
                    if (!tcToRevision.isEmpty() && revision != null) {
                        if (this.compareRevision(tcToRevision, revision) < 0) {
                            message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_RANGE_DIFFERENT);
                            return false;
                        }
                    }
                } else if (dif < 0) {
                    message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_RANGE_DIFFERENT);
                    return false;
                }
            } catch (NumberFormatException exception) {
                message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_RANGE_WRONGFORMAT);
                return false;
            }
        }

        return true;
    }

    private boolean checkTargetBuildRevision(TestCaseExecution tCExecution) {
        MyLogger.log(ExecutionCheckService.class.getName(), Level.DEBUG, "Checking target build");
        TCase tc = tCExecution.gettCase();
        CountryEnvParam env = tCExecution.getCountryEnvParam();
        String tcSprint = ParameterParserUtil.parseStringParam(tc.getTargetSprint(), "");
        String tcRevision = ParameterParserUtil.parseStringParam(tc.getTargetRevision(), "");
        String sprint = ParameterParserUtil.parseStringParam(env.getBuild(), "");
        String revision = ParameterParserUtil.parseStringParam(env.getRevision(), "");

        if (!tcSprint.isEmpty() && sprint != null) {
            try {
                int dif = this.compareBuild(sprint, tcSprint);
                if (dif == 0) {
                    if (!tcRevision.isEmpty() && revision != null) {
                        if (this.compareRevision(revision, tcRevision) < 0) {
                            message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_TARGET_DIFFERENT);
                            return false;
                        }
                    }
                } else if (dif < 0) {
                    message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_TARGET_DIFFERENT);
                    return false;
                }
            } catch (NumberFormatException exception) {
                message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_TARGET_WRONGFORMAT);
                return false;
            }
        }
        return true;
    }

    private boolean checkActiveEnvironmentGroup(TestCaseExecution tCExecution) {
        MyLogger.log(ExecutionCheckService.class.getName(), Level.DEBUG, "Checking environment " + tCExecution.getCountryEnvParam().getEnvironment());
        TCase tc = tCExecution.gettCase();
        if (tCExecution.getEnvironmentDataObj().getGp1().equalsIgnoreCase("QA")) {
            return this.checkRunQA(tc, tCExecution.getEnvironmentData());
        } else if (tCExecution.getEnvironmentDataObj().getGp1().equalsIgnoreCase("UAT")) {
            return this.checkRunUAT(tc, tCExecution.getEnvironmentData());
        } else if (tCExecution.getEnvironmentDataObj().getGp1().equalsIgnoreCase("PROD")) {
            return this.checkRunPROD(tc, tCExecution.getEnvironmentData());
        } else if (tCExecution.getEnvironmentDataObj().getGp1().equalsIgnoreCase("DEV")) {
            return true;
        }
        message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_ENVIRONMENT_NOTDEFINED);
        message.setDescription(message.getDescription().replaceAll("%ENV%", tCExecution.getEnvironmentData()));
        message.setDescription(message.getDescription().replaceAll("%ENVGP%", tCExecution.getEnvironmentDataObj().getGp1()));
        return false;
    }

    private boolean checkRunQA(TCase tc, String env) {
        if (tc.getRunQA().equals("Y")) {
            return true;
        }
        message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_RUNQA_NOTDEFINED);
        message.setDescription(message.getDescription().replaceAll("%ENV%", env));
        return false;
    }

    private boolean checkRunUAT(TCase tc, String env) {
        if (tc.getRunUAT().equals("Y")) {
            return true;
        }
        message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_RUNUAT_NOTDEFINED);
        message.setDescription(message.getDescription().replaceAll("%ENV%", env));
        return false;
    }

    private boolean checkRunPROD(TCase tc, String env) {
        if (tc.getRunPROD().equals("Y")) {
            return true;
        }
        message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_RUNPROD_NOTDEFINED);
        message.setDescription(message.getDescription().replaceAll("%ENV%", env));
        return false;
    }

    private boolean checkCountry(TestCaseExecution tCExecution) {
        MyLogger.log(ExecutionCheckService.class.getName(), Level.DEBUG, "Checking if country is setup for this testcase. " + tCExecution.getTest() + "-" + tCExecution.getTestCase() + "-" + tCExecution.getCountry());
        try {
            testCaseCountryService.findTestCaseCountryByKey(tCExecution.getTest(), tCExecution.getTestCase(), tCExecution.getCountry());
        } catch (CerberusException e) {
            message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_COUNTRY_NOTDEFINED);
            return false;
        }
        return true;
    }

    private int compareBuild(String build1, String build2) {
        if (build1.length() > 5 && build2.length() > 5) {
            int year1 = Integer.parseInt(build1.substring(0, 4));
            int num1 = Integer.parseInt(build1.substring(5));
            int year2 = Integer.parseInt(build2.substring(0, 4));
            int num2 = Integer.parseInt(build2.substring(5));

            if (year1 > year2) {
                return 1;
            } else if (year1 < year2) {
                return -1;
            } else {
                if (num1 > num2) {
                    return 1;
                } else if (num1 < num2) {
                    return -1;
                } else {
                    return 0;
                }
            }
        }
        throw new NumberFormatException();
    }

    private int compareRevision(String rev1, String rev2) {
        if (rev1.length() > 2 && rev2.length() > 2) {
            char tcLetter = rev1.charAt(0);
            int tcRev = Integer.parseInt(rev1.substring(1));
            char letter = rev2.charAt(0);
            int rev = Integer.parseInt(rev2.substring(1));

            if (tcLetter > letter) {
                return 1;
            } else if (tcLetter < letter) {
                return -1;
            } else {
                if (tcRev > rev) {
                    return 1;
                } else if (tcRev < rev) {
                    return -1;
                } else {
                    return 0;
                }
            }
        }
        throw new NumberFormatException();
    }

    private boolean checkMaintenanceTime(TestCaseExecution tCExecution) {
        if (tCExecution.getCountryEnvParam().isMaintenanceAct()) {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
            String nowDate = sdf.format(new Date());

            try {
                long now = sdf.parse(nowDate).getTime();
                long startMaintenance = sdf.parse(tCExecution.getCountryEnvParam().getMaintenanceStr()).getTime();
                long endMaintenance = sdf.parse(tCExecution.getCountryEnvParam().getMaintenanceStr()).getTime();

                if (!(now > startMaintenance && now < endMaintenance)) {
                    return true;
                }

            } catch (ParseException exception) {
                MyLogger.log(ExecutionCheckService.class.getName(), Level.ERROR, exception.toString());
            }
            message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_ENVIRONMENT_UNDER_MAINTENANCE);
            return false;
        }
        return true;
    }

    private boolean checkVerboseIsNotZeroForFirefoxOnly(TestCaseExecution tCExecution) {
        if (!tCExecution.getBrowser().equalsIgnoreCase("firefox")) {
            if (tCExecution.getVerbose() > 0) {
                message = new MessageGeneral(MessageGeneralEnum.VALIDATION_FAILED_VERBOSE_USED_WITH_INCORRECT_BROWSER);
                return false;
            }
        }
        return true;
    }
}
