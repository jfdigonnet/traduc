Cerberus
========

Automated testing framework.
